package BankApplication.Exeptions;

public class WeekPasswordException extends Exception{

    public WeekPasswordException(String message) {
        super(message);
    }
}
